function [ LBPhist ] = ULBP_window40(I2) 
[ LBPhist ] = ULBP_Generic(I2,10,40);
end