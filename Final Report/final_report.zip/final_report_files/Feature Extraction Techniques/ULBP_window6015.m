function [ LBPhist ] = ULBP_window6015(I2) 
[ LBPhist ] = ULBP_Generic(I2,15,60);
end