function [ LBPhist ] = ULBP_window50(I2) 
[ LBPhist ] = ULBP_Generic(I2,10,50);
end