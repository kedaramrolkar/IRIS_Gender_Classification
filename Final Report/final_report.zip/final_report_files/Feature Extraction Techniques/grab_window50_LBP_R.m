function Grab_vector = grab_window50_LBP_R(I2)
    Grab_vector = grab_generic_LBP_R(I2,10,50);
end