function [ LBPhist ] = CULBPC_window50(I2) 
[ LBPhist ] = CULBPC_Generic(I2,10,50);
end