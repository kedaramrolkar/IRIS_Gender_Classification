function [ LBPhist ] = ULBP_window(I2) 
[ LBPhist ] = ULBP_Generic(I2,10);
end