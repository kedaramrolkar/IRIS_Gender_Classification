function [ LBPhist ] = ULBP_window60(I2) 
[ LBPhist ] = ULBP_Generic(I2,10,60);
end