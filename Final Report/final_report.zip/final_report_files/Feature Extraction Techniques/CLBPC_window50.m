function [ LBPhist ] = CLBPC_window50(I2) 
[ LBPhist ] = CLBPC_Generic(I2,10,50);
end