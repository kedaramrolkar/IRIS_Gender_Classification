function [ LBPhist ] = LBP_window(I2) 
[ LBPhist ] = LBP_Generic(I2,10);
end