function Grab_vector = grab_window_ULBP(I2)
    Grab_vector = grab_generic_ULBP(I2,10);
end