function [ LBPhist ] = ULBP_window8015(I2) 
[ LBPhist ] = ULBP_Generic(I2,15,80);
end