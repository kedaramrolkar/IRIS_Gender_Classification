function [ LBPhist ] = LBP_window50(I2) 
[ LBPhist ] = LBP_Generic(I2,10,50);
end