function Grab_vector = grab_window50_ULBP(I2)
    Grab_vector = grab_generic_ULBP(I2,10,50);
end