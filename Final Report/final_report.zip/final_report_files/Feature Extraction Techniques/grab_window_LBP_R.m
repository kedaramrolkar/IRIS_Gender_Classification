function Grab_vector = grab_window_LBP_R(I2)
    Grab_vector = grab_generic_LBP_R(I2,10);
end